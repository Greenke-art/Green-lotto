# Green Lotto

Application form + M-Pesa STK Push entry payment for a travel-prize draw.

## ⚠️ Before you launch — read this

1. **Get a promotion permit.** In Kenya, any competition where entrants pay
   money for a chance at a prize is regulated by the **Betting Control and
   Licensing Board (BCLB)**. Running this live without a permit is illegal,
   regardless of how well the code works.
2. **Don't imply this is the US Diversity Visa Lottery.** That program is
   free and run by the US government. Keep your copy clear that Green Lotto
   is a private promotion offering a travel package, not an immigration or
   visa service.
3. **How the M-Pesa payment actually works:** the applicant enters their PIN
   **on their own phone**, in the native M-Pesa STK push prompt — never on
   this website. This app never sees or stores any PIN. If anyone asks you
   to build a form field that captures a PIN, that's a phishing pattern —
   don't build it.

## How it works

1. Applicant fills the form (`frontend/index.html`) → saved via `POST /api/apply`.
2. Applicant taps "Send M-Pesa prompt" → backend calls Safaricom's Daraja
   **STK Push** API (`POST /api/payment/stkpush`), which pushes a payment
   prompt to their phone.
3. Applicant enters their M-Pesa PIN on their own device to approve payment.
4. Safaricom calls your backend back at `POST /api/payment/callback` with
   the result. The frontend polls `GET /api/payment/status/:checkoutRequestId`
   until it sees `paid` or `failed`.
5. On success, a ticket number is generated and shown as a boarding-pass-style
   confirmation.

## Setup

### 1. Get Daraja API credentials
Register at https://developer.safaricom.co.ke, create an app, and get:
- Consumer Key & Secret
- A shortcode (sandbox default: `174379`)
- A Lipa Na M-Pesa Online **passkey**

### 2. Backend
```bash
cd backend
cp .env.example .env
# edit .env with your real Daraja credentials
npm install
npm start
```
Server runs on `http://localhost:4000` by default.

### 3. Callback URL (important)
Safaricom needs a **public HTTPS URL** to call `POST /api/payment/callback`.
For local testing, use a tunnel:
```bash
ngrok http 4000
```
Then set `DARAJA_CALLBACK_URL` in `.env` to the ngrok HTTPS URL + `/api/payment/callback`,
and restart the server.

### 4. Frontend
The Express server already serves `frontend/` as static files, so once the
backend is running, just open `http://localhost:4000` in a browser.
For separate hosting, deploy `frontend/` anywhere static (Netlify, Vercel, S3)
and update `API_BASE` in `app.js` to your backend's URL.

### 5. Go live
- Switch `DARAJA_ENV=production` in `.env`
- Use your real Paybill/Till shortcode and production passkey
- Point `DARAJA_CALLBACK_URL` at your real production domain

## Data collected per applicant
Full name, email, phone, National ID number, age, employment status,
address, plus payment status, M-Pesa receipt number, and a generated
ticket number. Stored in `backend/green-lotto.db` (SQLite).

Treat this database as sensitive — it contains personal ID numbers. Don't
commit it to version control, and follow Kenya's Data Protection Act when
handling and storing it.
